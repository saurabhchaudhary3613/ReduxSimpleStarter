
export default function () {
    return [
        {title: 'Javascript'},
        {title: 'Harry Poter'},
        {title: 'The dark side'},
        {title: 'ABC'}
    ]
}